"""
REDSWARM — Beispiel-Agent Template
====================================
Kopiere diese Datei für jeden neuen Agent.
Passe nur: AGENT_ID, NAME, DESCRIPTION, CAPABILITIES, TARGET_TYPES
und die run()-Funktion an.

Kommunikationsfluss:
  1. Beim Start: register() → Backend weiß dass dieser Agent existiert
  2. Wenn Mission startet: FastAPI ruft /run auf (HTTP POST)
  3. Agent sendet Updates via send_update() → Backend → WebSocket → UI
"""

import os
import asyncio
import httpx
from fastapi import FastAPI
from pydantic import BaseModel

# ─────────────────────────────────────────────
# AGENT IDENTITY — NUR DIESE FELDER ANPASSEN
# ─────────────────────────────────────────────
AGENT_ID     = "recon-agent-v1"
AGENT_NAME   = "Recon Agent"
AGENT_DESC   = "Scannt DNS, Subdomains, offene Ports und HTTP-Header"
AGENT_ICON   = "🔭"
CAPABILITIES = ["dns-enum", "subdomain-scan", "port-scan", "header-analysis"]
TARGET_TYPES = ["webapp", "api", "network"]
AGENT_PORT   = int(os.getenv("AGENT_PORT", "8100"))

# ─────────────────────────────────────────────
# ENVIRONMENT (wird vom Backend per Env gesetzt)
# ─────────────────────────────────────────────
BACKEND_URL    = os.getenv("BACKEND_URL", "http://backend:8000")
AGENT_BASE_URL = os.getenv("AGENT_BASE_URL", f"http://recon-agent:{AGENT_PORT}")

# ─────────────────────────────────────────────
# FASTAPI APP (empfängt Missions vom Backend)
# ─────────────────────────────────────────────
agent_app = FastAPI(title=AGENT_NAME)


class MissionPayload(BaseModel):
    mission_id:  str
    target_url:  str
    target_type: str
    intensity:   str
    options:     dict = {}
    update_url:  str
    api_key:     str


# ─────────────────────────────────────────────
# HELPER: Update ans Backend senden
# ─────────────────────────────────────────────

async def send_update(update_url: str, api_key: str, event_type: str, payload: dict):
    """
    Sendet ein Update an das Backend.
    Das Backend leitet es per WebSocket an die UI weiter.

    event_type:
      "progress"  → payload: {"percent": 0-100, "current_task": "..."}
      "finding"   → payload: {"severity": "KRITISCH|HOCH|MITTEL|INFO", "title": "...", "description": "..."}
      "log"       → payload: {"level": "info|warn|error", "message": "..."}
      "complete"  → payload: {"summary": "..."}
      "error"     → payload: {"message": "..."}
    """
    body = {
        "api_key": api_key,
        "update": {
            "agent_id":   AGENT_ID,
            "event_type": event_type,
            "payload":    payload,
        }
    }
    async with httpx.AsyncClient(timeout=5.0) as client:
        try:
            await client.post(update_url, json=body)
        except Exception as e:
            print(f"[{AGENT_ID}] Update fehlgeschlagen: {e}")


# ─────────────────────────────────────────────
# AGENT LOGIK — HIER DEINE IMPLEMENTATION
# ─────────────────────────────────────────────

async def run(payload: MissionPayload):
    """
    Hauptlogik des Agents.
    Sende regelmäßig Updates und Findings.
    """
    upd = payload.update_url
    key = payload.api_key
    target = payload.target_url

    # ── Phase 1: DNS Enumeration ──────────────
    await send_update(upd, key, "log", {
        "level":   "info",
        "message": f"Starte DNS-Analyse für {target}"
    })
    await send_update(upd, key, "progress", {
        "percent":      10,
        "current_task": "DNS-Einträge abrufen"
    })

    # Hier echte Logik implementieren:
    # dns_results = await run_dns_enum(target)
    await asyncio.sleep(2)  # Platzhalter

    await send_update(upd, key, "progress", {
        "percent":      30,
        "current_task": "Subdomains scannen"
    })

    # ── Phase 2: Port Scan ────────────────────
    # Intensität berücksichtigen
    port_range = {
        "low":      "80,443,8080",
        "medium":   "80,443,8080,8443,3000",
        "high":     "1-10000",
        "critical": "1-65535",
    }.get(payload.intensity, "80,443,8080")

    await send_update(upd, key, "log", {
        "level":   "info",
        "message": f"Port-Scan ({port_range})"
    })
    await asyncio.sleep(3)  # Platzhalter für echten Scan

    await send_update(upd, key, "progress", {
        "percent":      60,
        "current_task": "HTTP-Header analysieren"
    })

    # ── Phase 3: Findings melden ──────────────
    # Beispiel: Wenn ein Finding gefunden wird
    await send_update(upd, key, "finding", {
        "severity":    "MITTEL",
        "title":       "Server-Version in HTTP-Header sichtbar",
        "description": "Der Server gibt seine genaue Version preis (Apache 2.4.51). "
                       "Dies erleichtert gezielten Angriff mit bekannten Exploits.",
        "evidence":    "Server: Apache/2.4.51 (Ubuntu)",
        "remediation": "ServerTokens auf 'Prod' setzen in Apache-Konfiguration.",
        "cvss_score":  4.3,
    })

    await send_update(upd, key, "progress", {
        "percent":      90,
        "current_task": "Ergebnisse zusammenfassen"
    })
    await asyncio.sleep(1)

    # ── Abschluss ─────────────────────────────
    await send_update(upd, key, "complete", {
        "summary": "Recon abgeschlossen. 1 Finding gefunden."
    })


# ─────────────────────────────────────────────
# HTTP ENDPOINT (Backend ruft hier auf)
# ─────────────────────────────────────────────

@agent_app.post("/run")
async def handle_run(payload: MissionPayload, background_tasks):
    """Backend ruft diesen Endpoint auf wenn eine Mission startet."""
    background_tasks.add_task(run, payload)
    return {"status": "started", "agent_id": AGENT_ID}


@agent_app.get("/health")
async def health():
    return {"agent_id": AGENT_ID, "status": "ready"}


# ─────────────────────────────────────────────
# STARTUP: Beim Start beim Backend registrieren
# ─────────────────────────────────────────────

@agent_app.on_event("startup")
async def startup():
    registration = {
        "agent_id":     AGENT_ID,
        "name":         AGENT_NAME,
        "description":  AGENT_DESC,
        "icon":         AGENT_ICON,
        "capabilities": CAPABILITIES,
        "target_types": TARGET_TYPES,
        "version":      "1.0.0",
        "callback_url": AGENT_BASE_URL,
    }
    # Retry loop — Backend muss noch nicht sofort verfügbar sein
    for attempt in range(10):
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                r = await client.post(f"{BACKEND_URL}/agents/register", json=registration)
                if r.status_code == 200:
                    print(f"[{AGENT_ID}] ✓ Registriert beim Backend")
                    return
        except Exception:
            pass
        await asyncio.sleep(3)
    print(f"[{AGENT_ID}] ✗ Konnte sich nicht registrieren")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(agent_app, host="0.0.0.0", port=AGENT_PORT)
