"""
REDSWARM Backend — FastAPI
==========================
Vollständig dynamisches Backend. Keine hardcodierten Agents oder Zieltypen.
Agents registrieren sich selbst. Die UI rendert nur was hier verfügbar ist.

Kommunikationsfluss:
  1. Agents registrieren sich via POST /agents/register
  2. UI holt verfügbare Agents via GET /agents
  3. UI startet Mission via POST /missions
  4. Backend startet Agents als async Tasks
  5. Agents pushen Updates via POST /missions/{id}/update
  6. UI empfängt Live-Updates via WebSocket ws://.../missions/{id}/ws
"""

import asyncio
import json
import uuid
import subprocess
import sys
from datetime import datetime
from typing import Any, Optional
from contextlib import asynccontextmanager

import httpx
import redis.asyncio as aioredis
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel


# ─────────────────────────────────────────────
# CONFIG (via Env-Variablen in Produktion)
# ─────────────────────────────────────────────
import os
REDIS_URL   = os.getenv("REDIS_URL",   "redis://redis:6379")
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")
API_KEY     = os.getenv("REDSWARM_API_KEY", "change-me-in-production")


# ─────────────────────────────────────────────
# STARTUP / SHUTDOWN
# ─────────────────────────────────────────────
redis_client: aioredis.Redis = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global redis_client
    redis_client = await aioredis.from_url(REDIS_URL, decode_responses=True)
    yield
    await redis_client.aclose()

app = FastAPI(title="REDSWARM API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # In Produktion: nur eigene Domain
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────
# IN-MEMORY STORES (in Prod: Postgres/Redis)
# ─────────────────────────────────────────────
registered_agents: dict[str, dict] = {}   # agent_id → AgentRegistration
active_missions:   dict[str, dict] = {}   # mission_id → MissionState
ws_connections:    dict[str, list[WebSocket]] = {}  # mission_id → [ws, ...]


# ─────────────────────────────────────────────
# SCHEMAS
# ─────────────────────────────────────────────

class AgentRegistration(BaseModel):
    """
    Jeder Agent registriert sich selbst mit diesen Daten.
    Die UI rendert daraus dynamisch die Agent-Auswahl.
    """
    agent_id:     str            # Eindeutige ID, z.B. "recon-v1"
    name:         str            # Anzeigename, z.B. "Recon Agent"
    description:  str            # Was dieser Agent tut
    icon:         str            # Emoji oder Icon-Code
    capabilities: list[str]      # z.B. ["dns", "subdomain", "port-scan"]
    target_types: list[str]      # z.B. ["webapp", "api", "network"]
    version:      str = "1.0.0"
    callback_url: Optional[str] = None  # Wo der Agent erreichbar ist


class MissionConfig(BaseModel):
    """
    Vollständig dynamisch — kein Feld ist auf spezifische Agents festgelegt.
    """
    name:         str
    target_url:   str
    target_type:  str            # Freier String, kommt vom User
    intensity:    str            # "low" | "medium" | "high" | "critical"
    agent_ids:    list[str]      # Welche registrierten Agents einsetzen
    options:      dict[str, Any] = {}  # Beliebige zusätzliche Config


class AgentUpdate(BaseModel):
    """
    Agents senden Live-Updates an das Backend.
    Das Backend broadcastet sie an alle WebSocket-Verbindungen der Mission.
    """
    agent_id:   str
    event_type: str   # "progress" | "finding" | "log" | "complete" | "error"
    payload:    dict[str, Any]


class UpdateAuth(BaseModel):
    api_key: str
    update:  AgentUpdate


# ─────────────────────────────────────────────
# WEBSOCKET BROADCAST HELPER
# ─────────────────────────────────────────────

async def broadcast(mission_id: str, event: dict):
    """Sendet ein Event an alle aktiven WS-Verbindungen dieser Mission."""
    dead = []
    for ws in ws_connections.get(mission_id, []):
        try:
            await ws.send_json(event)
        except Exception:
            dead.append(ws)
    for ws in dead:
        ws_connections[mission_id].remove(ws)

    # Auch in Redis pushen (für Replay bei neuer WS-Verbindung)
    await redis_client.rpush(
        f"mission:{mission_id}:events",
        json.dumps(event)
    )
    await redis_client.expire(f"mission:{mission_id}:events", 86400)  # 24h TTL


# ─────────────────────────────────────────────
# AGENT REGISTRY ENDPOINTS
# ─────────────────────────────────────────────

@app.post("/agents/register", tags=["Agents"])
async def register_agent(reg: AgentRegistration):
    """
    Agents rufen diesen Endpoint beim Start auf.
    Danach erscheinen sie automatisch in der UI.
    """
    registered_agents[reg.agent_id] = reg.model_dump()
    registered_agents[reg.agent_id]["registered_at"] = datetime.utcnow().isoformat()
    return {"status": "registered", "agent_id": reg.agent_id}


@app.get("/agents", tags=["Agents"])
async def list_agents():
    """UI holt diese Liste um die Agent-Auswahl dynamisch zu rendern."""
    return list(registered_agents.values())


@app.delete("/agents/{agent_id}", tags=["Agents"])
async def unregister_agent(agent_id: str):
    if agent_id not in registered_agents:
        raise HTTPException(404, "Agent nicht gefunden")
    del registered_agents[agent_id]
    return {"status": "unregistered"}


# ─────────────────────────────────────────────
# MISSION ENDPOINTS
# ─────────────────────────────────────────────

@app.post("/missions", tags=["Missions"])
async def create_mission(config: MissionConfig, background_tasks: BackgroundTasks):
    """Erstellt und startet eine Mission."""
    # Validierung: Alle gewählten Agents müssen registriert sein
    unknown = [aid for aid in config.agent_ids if aid not in registered_agents]
    if unknown:
        raise HTTPException(400, f"Unbekannte Agents: {unknown}")

    mission_id = str(uuid.uuid4())
    mission = {
        "id":         mission_id,
        "config":     config.model_dump(),
        "status":     "running",
        "started_at": datetime.utcnow().isoformat(),
        "findings":   [],
        "agent_states": {
            aid: {"progress": 0, "status": "pending", "current_task": ""}
            for aid in config.agent_ids
        },
    }
    active_missions[mission_id] = mission
    ws_connections[mission_id] = []

    # Agents asynchron starten
    background_tasks.add_task(dispatch_agents, mission_id, config)

    return {"mission_id": mission_id, "status": "running"}


@app.get("/missions/{mission_id}", tags=["Missions"])
async def get_mission(mission_id: str):
    if mission_id not in active_missions:
        raise HTTPException(404, "Mission nicht gefunden")
    return active_missions[mission_id]


@app.get("/missions", tags=["Missions"])
async def list_missions():
    return list(active_missions.values())


@app.post("/missions/{mission_id}/stop", tags=["Missions"])
async def stop_mission(mission_id: str):
    if mission_id not in active_missions:
        raise HTTPException(404, "Mission nicht gefunden")
    active_missions[mission_id]["status"] = "stopped"
    await broadcast(mission_id, {"event": "mission_stopped", "timestamp": datetime.utcnow().isoformat()})
    return {"status": "stopped"}


# ─────────────────────────────────────────────
# AGENT UPDATE ENDPOINT (Agents → Backend)
# ─────────────────────────────────────────────

@app.post("/missions/{mission_id}/update", tags=["Missions"])
async def receive_agent_update(mission_id: str, body: UpdateAuth):
    """
    Agents rufen diesen Endpoint auf um Updates zu senden.
    Das Backend broadcastet sie an die UI via WebSocket.
    """
    if body.api_key != API_KEY:
        raise HTTPException(403, "Ungültiger API-Key")
    if mission_id not in active_missions:
        raise HTTPException(404, "Mission nicht gefunden")

    update = body.update
    mission = active_missions[mission_id]

    event = {
        "event":      update.event_type,
        "agent_id":   update.agent_id,
        "payload":    update.payload,
        "timestamp":  datetime.utcnow().isoformat(),
    }

    # Mission-State aktualisieren
    if update.event_type == "progress":
        if update.agent_id in mission["agent_states"]:
            mission["agent_states"][update.agent_id].update({
                "progress":     update.payload.get("percent", 0),
                "status":       "running",
                "current_task": update.payload.get("current_task", ""),
            })

    elif update.event_type == "finding":
        finding = {
            "id":          str(uuid.uuid4()),
            "agent_id":    update.agent_id,
            "found_at":    datetime.utcnow().isoformat(),
            **update.payload,
        }
        mission["findings"].append(finding)

    elif update.event_type == "complete":
        if update.agent_id in mission["agent_states"]:
            mission["agent_states"][update.agent_id]["status"] = "done"
            mission["agent_states"][update.agent_id]["progress"] = 100
        # Alle done? → Mission complete
        all_done = all(
            s["status"] == "done"
            for s in mission["agent_states"].values()
        )
        if all_done:
            mission["status"] = "complete"
            mission["finished_at"] = datetime.utcnow().isoformat()

    elif update.event_type == "error":
        if update.agent_id in mission["agent_states"]:
            mission["agent_states"][update.agent_id]["status"] = "error"

    # An WebSocket-Clients broadcasten
    await broadcast(mission_id, event)
    return {"status": "ok"}


# ─────────────────────────────────────────────
# WEBSOCKET (Backend → UI Live-Stream)
# ─────────────────────────────────────────────

@app.websocket("/missions/{mission_id}/ws")
async def mission_websocket(ws: WebSocket, mission_id: str):
    await ws.accept()

    if mission_id not in active_missions:
        await ws.send_json({"event": "error", "message": "Mission nicht gefunden"})
        await ws.close()
        return

    # Alle bisherigen Events aus Redis replay-en (für späten Connect)
    past_events = await redis_client.lrange(f"mission:{mission_id}:events", 0, -1)
    for raw in past_events:
        await ws.send_json(json.loads(raw))

    # Aktuellen State senden
    await ws.send_json({
        "event":   "state_sync",
        "payload": active_missions[mission_id],
        "timestamp": datetime.utcnow().isoformat(),
    })

    ws_connections[mission_id].append(ws)
    try:
        while True:
            # Heartbeat vom Client
            await ws.receive_text()
    except WebSocketDisconnect:
        ws_connections[mission_id].remove(ws)


# ─────────────────────────────────────────────
# AGENT DISPATCH (startet Agents via HTTP)
# ─────────────────────────────────────────────

async def dispatch_agents(mission_id: str, config: MissionConfig):
    """
    Ruft den callback_url jedes Agents auf um die Mission zu starten.
    Agents bekommen: mission_id, target, options, callback_url für Updates.
    """
    await broadcast(mission_id, {
        "event":     "mission_started",
        "payload":   {"agent_count": len(config.agent_ids)},
        "timestamp": datetime.utcnow().isoformat(),
    })

    async with httpx.AsyncClient(timeout=10.0) as client:
        tasks = []
        for agent_id in config.agent_ids:
            agent = registered_agents.get(agent_id)
            if not agent or not agent.get("callback_url"):
                # Agent hat keine callback_url → als lokales Skript starten
                tasks.append(start_local_agent(mission_id, agent_id, config))
                continue

            payload = {
                "mission_id":   mission_id,
                "target_url":   config.target_url,
                "target_type":  config.target_type,
                "intensity":    config.intensity,
                "options":      config.options,
                "update_url":   f"{BACKEND_URL}/missions/{mission_id}/update",
                "api_key":      API_KEY,
            }
            tasks.append(
                client.post(f"{agent['callback_url']}/run", json=payload)
            )

        await asyncio.gather(*tasks, return_exceptions=True)


async def start_local_agent(mission_id: str, agent_id: str, config: MissionConfig):
    """
    Fallback: Agent als Python-Subprocess starten.
    Erwartet: agents/{agent_id}/run.py
    """
    script = f"agents/{agent_id}/run.py"
    if not os.path.exists(script):
        await broadcast(mission_id, {
            "event":    "log",
            "agent_id": agent_id,
            "payload":  {"level": "warn", "message": f"Kein Script gefunden: {script}"},
            "timestamp": datetime.utcnow().isoformat(),
        })
        return

    env = {
        **os.environ,
        "MISSION_ID":   mission_id,
        "TARGET_URL":   config.target_url,
        "TARGET_TYPE":  config.target_type,
        "INTENSITY":    config.intensity,
        "UPDATE_URL":   f"{BACKEND_URL}/missions/{mission_id}/update",
        "API_KEY":      API_KEY,
    }
    proc = await asyncio.create_subprocess_exec(
        sys.executable, script,
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    await proc.communicate()


# ─────────────────────────────────────────────
# HEALTH CHECK
# ─────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "agents": len(registered_agents), "missions": len(active_missions)}
